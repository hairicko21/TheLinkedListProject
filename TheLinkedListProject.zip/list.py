list = []
list.append(111)
list.append(222)
list.append(333)
print(list)
class stack:

	def __init__(self):
		print('initialising')


stack1 = stack() # creating an object 'stack1' of the stack class
stack2 = stack() # creating an object 'stack2' of the stack class

